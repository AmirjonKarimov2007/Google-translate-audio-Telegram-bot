from aiogram.utils.callback_data import CallbackData
channels_callback = CallbackData("channels","1_kanal")
yes_or_no_callback = CallbackData("confirm","ha")